NAME: MEAKEN
SURNAME: GUMBI
STUDENT NUMBER: ST10166513
_____________________________
# Study Time Calculator

## Description

The Study Time Calculator Application helps students and individuals manage their study time effectively. It allows users to add, view, and update module details, including module code, name, credits, class hours, and self-study hours.

## Requirements

- Microsoft Visual Studio (for development)
- .NET Framework (or .NET Core)

## Installation

1. Clone this repository.
2. Open the solution in Visual Studio.
3. Build and run the application.

## Usage

1. Launch the application.
2. Enter module details (module code, name, etc.) and click the "Add" button.
3. Click the "View" button to see a list of added modules.
4. To update self-study hours for a module:
   - Enter the module code, new hours, and select a date.
   - Click the "Update" button.

## Screenshots

![Screenshot 1](/screenshots/screenshot1.png)

## Advanced Features

- Exception handling to prevent incorrect input.
- LINQ for displaying module details.
- Custom class library for calculations.
- Good coding practices, including comments and code organization.

## License

This project is licensed under the [MIT License](LICENSE).

## Contact

For questions or feedback, please contact Meaken Gumbi at meaken@example.com.

